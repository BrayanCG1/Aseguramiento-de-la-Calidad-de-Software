package javaapplication1;

import btn_Solicitud.Equipos_ComputoController;
import btn_Solicitud.PerifericosController;
import btn_Solicitud.Red_y_comunicacionesController;
import btn_Solicitud.Sala_ReunionesController;
import btn_Solicitud.TransporteController;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.layout.AnchorPane;
import java.io.IOException;
import tabla.tablaController;

/**
 * Clase controladora para gestionar eventos y
 * cargar diferentes paneles FXML.
 */
public class FXMLController implements Initializable {

    @FXML
    private AnchorPane opciones; // Panel de opciones
    @FXML
    private AnchorPane calendario; // Panel de calendario
    @FXML
    private AnchorPane tabla;
    private String fileName;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Inicialización del controlador si es necesario
        loadTablaPane();
    }

    @FXML
    private void btn_Equipos() {
       
         try {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/btn_Solicitud/Equipos_Computo.fxml"));
        AnchorPane pane = loader.load();

        // Obtener el controlador del archivo FXML cargado
        Object controller = loader.getController();
        
        // Si el controlador es `Equipos_ComputoController`, pasar el AnchorPane `tabla`
        if (controller instanceof Equipos_ComputoController) {
            ((Equipos_ComputoController) controller).setTablaPane(tabla);
        }

        // Limpiar el contenido actual del panel 'opciones' antes de agregar el nuevo
        opciones.getChildren().clear();
        opciones.getChildren().add(pane);
    } catch (IOException e) {
        e.printStackTrace();
    }
    loadCalendarioPane();
    }

    @FXML
    private void btn_Perifericos() {
        
         try {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/btn_Solicitud/Perifericos.fxml"));
        AnchorPane pane = loader.load();

        // Obtener el controlador del archivo FXML cargado
        Object controller = loader.getController();
        
        // Si el controlador es `Equipos_ComputoController`, pasar el AnchorPane `tabla`
        if (controller instanceof PerifericosController) {
            ((PerifericosController) controller).setTablaPane(tabla);
        }

        // Limpiar el contenido actual del panel 'opciones' antes de agregar el nuevo
        opciones.getChildren().clear();
        opciones.getChildren().add(pane);
    } catch (IOException e) {
        e.printStackTrace();
    }
    loadCalendarioPane();
    }

    @FXML
    private void btn_Comunicaciones() {
         try {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/btn_Solicitud/Red_y_comunicaciones.fxml"));
        AnchorPane pane = loader.load();

        // Obtener el controlador del archivo FXML cargado
        Object controller = loader.getController();
        
        // Si el controlador es `Equipos_ComputoController`, pasar el AnchorPane `tabla`
        if (controller instanceof Red_y_comunicacionesController) {
            ((Red_y_comunicacionesController) controller).setTablaPane(tabla);
        }

        // Limpiar el contenido actual del panel 'opciones' antes de agregar el nuevo
        opciones.getChildren().clear();
        opciones.getChildren().add(pane);
    } catch (IOException e) {
        e.printStackTrace();
    }
    loadCalendarioPane();
    }

    @FXML
    private void btn_Sala_Reunion() {
         try {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/btn_Solicitud/Sala_Reunion.fxml"));
        AnchorPane pane = loader.load();

        // Obtener el controlador del archivo FXML cargado
        Object controller = loader.getController();
        
        // Si el controlador es `Equipos_ComputoController`, pasar el AnchorPane `tabla`
        if (controller instanceof Sala_ReunionesController) {
            ((Sala_ReunionesController) controller).setTablaPane(tabla);
        }

        // Limpiar el contenido actual del panel 'opciones' antes de agregar el nuevo
        opciones.getChildren().clear();
        opciones.getChildren().add(pane);
    } catch (IOException e) {
        e.printStackTrace();
    }
    loadCalendarioPane();
    }

    @FXML
    private void btn_Transporte() {
         try {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/btn_Solicitud/Transporte.fxml"));
        AnchorPane pane = loader.load();

        // Obtener el controlador del archivo FXML cargado
        Object controller = loader.getController();
        
        // Si el controlador es `Equipos_ComputoController`, pasar el AnchorPane `tabla`
        if (controller instanceof TransporteController) {
            ((TransporteController) controller).setTablaPane(tabla);
        }

        // Limpiar el contenido actual del panel 'opciones' antes de agregar el nuevo
        opciones.getChildren().clear();
        opciones.getChildren().add(pane);
    } catch (IOException e) {
        e.printStackTrace();
    }
    loadCalendarioPane();
    }

    @FXML
    private void ap_Opciones() {
        // Método vacío para posibles eventos relacionados con el panel 'opciones'.
    }
    @FXML
private void ap_Calendario() {
    // Lógica del método aquí
}

   @FXML
private void ap_Tabla() {
    // Lógica del método aquí
}

    private void loadCalendarioPane() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/MainView.fxml"));
            AnchorPane pane = loader.load();

            // Limpiar el contenido actual del panel 'calendario' antes de agregar el nuevo
            calendario.getChildren().clear();
            calendario.getChildren().add(pane);
        } catch (IOException e) {
            // Manejo de excepciones en caso de fallo al cargar el archivo FXML
            e.printStackTrace();
            System.out.println("Error loading Calendario.fxml");
        }
    }
    
     private void loadTablaPane() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/tabla/table.fxml"));
            AnchorPane pane = loader.load();

            // Limpiar el contenido actual del panel 'calendario' antes de agregar el nuevo
            tabla.getChildren().clear();
            tabla.getChildren().add(pane);
        } catch (IOException e) {
            // Manejo de excepciones en caso de fallo al cargar el archivo FXML
            e.printStackTrace();
            System.out.println("Error loading Calendario.fxml");
        }
    }
 
}
