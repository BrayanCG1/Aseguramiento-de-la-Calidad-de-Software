package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

public class MainController {

    @FXML
    private Button CrearReserva;

@FXML
    void btnCrearReserva(ActionEvent event) {
        JOptionPane.showInternalMessageDialog(null, "Se ha creado su reserva");
        Alert alerta= new Alert(Alert.AlertType.CONFIRMATION,"Se ha craeado su reserva");
        alerta.showAndWait();
    }

}