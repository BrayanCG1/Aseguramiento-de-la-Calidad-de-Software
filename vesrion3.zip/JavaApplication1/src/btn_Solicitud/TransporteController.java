/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package btn_Solicitud;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import tabla.tablaController;

/**
 * Controlador para la interfaz gráfica relacionada con "Transporte".
 * Implementa la interfaz Initializable, lo que significa que tiene un método initialize
 * que se ejecuta al cargar el archivo FXML.
 *
 * Métodos:
 * - initialize(URL url, ResourceBundle rb): Método para inicializar el controlador.
 * - btn_vehiculo_Personal(ActionEvent event): Maneja el evento del botón "Vehículo Personal".
 * - bts_Minibus(ActionEvent event): Maneja el evento del botón "Minibús".
 * - btn_Bicicletas(ActionEvent event): Maneja el evento del botón "Bicicletas".
 * - btn_reservas_Vuelos(ActionEvent event): Maneja el evento del botón "Reservas de Vuelos".
 * 
 * Autor: parca
 */
public class TransporteController {
    private AnchorPane tabla; // Pane donde se mostrará `table.fxml`

    // Método para establecer el AnchorPane `tabla`
    public void setTablaPane(AnchorPane tabla) {
        this.tabla = tabla;
    }

    @FXML
    private void btnPresionado(ActionEvent event) {
        // Obtener el texto del botón presionado
        String buttonName = ((Button) event.getSource()).getText();
        System.out.println("Botón presionado: " + buttonName); // Para verificar el nombre del botón

        // Cargar `table.fxml` en el AnchorPane `tabla` con el nombre del botón
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/tabla/table.fxml"));
            Parent root = loader.load();

            // Obtener el controlador de `tablaController`
            tablaController controller = loader.getController();
            controller.setFileName(buttonName);  // Enviar el nombre del botón

            // Limpiar el contenido de `tabla` y añadir el contenido de `table.fxml`
            tabla.getChildren().clear();
            tabla.getChildren().add(root);
        } catch (IOException e) {
            e.printStackTrace();
        }
}
}
