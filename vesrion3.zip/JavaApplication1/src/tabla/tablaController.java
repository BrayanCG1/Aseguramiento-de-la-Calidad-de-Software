package tabla;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;   
import java.sql.Statement;
import javaapplication1.JavaApplication1;

public class tablaController {
    
    private String fileName;

    @FXML
    private TableView<tablaContenido> tablaMobiliario;
    @FXML
    private TableColumn<tablaContenido, Integer> colIdMobiliario;
    @FXML
    private TableColumn<tablaContenido, String> colNombre;
    @FXML
    private TableColumn<tablaContenido, String> colDescripcion;
    @FXML
    private TableColumn<tablaContenido, String> colStock;

    private ObservableList<tablaContenido> listaMobiliario = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        // Configurar columnas
        colIdMobiliario.setCellValueFactory(new PropertyValueFactory<>("id_Mobiliario"));
        colNombre.setCellValueFactory(new PropertyValueFactory<>("Nombre"));
        colDescripcion.setCellValueFactory(new PropertyValueFactory<>("Descripcion"));
        colStock.setCellValueFactory(new PropertyValueFactory<>("Cantidad"));
    }

    private void realizarConsulta() {
        Connection con = JavaApplication1.getConnection(); // Obtener conexión desde JavaApplication1
        listaMobiliario.clear(); // Limpiar la lista para evitar datos duplicados
        try {
            if (con != null) {
                Statement st = con.createStatement();
                System.out.println("Conectado a la base de datos 'mydatabase'");

                ResultSet rs = st.executeQuery("SELECT * FROM mobiliario WHERE Subtipo = '" + fileName + "'");

                while (rs.next()) {
                    int idMobiliario = rs.getInt("id_Mobiliario");
                    String nombre = rs.getString("Nombre");
                    String descripcion = rs.getString("Descripcion");
                    String cantidad = rs.getString("Cantidad");

                    listaMobiliario.add(new tablaContenido(idMobiliario, nombre, descripcion, cantidad));
                }

                // Asignar la lista a la tabla
                tablaMobiliario.setItems(listaMobiliario);
                rs.close();
            }
        } catch (SQLException e) {
            System.err.println("Error al realizar la consulta: " + e.getMessage());
        }
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
        realizarConsulta();
    }
}
